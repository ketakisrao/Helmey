module.exports = {
    accountSid : 'AC9d4cd8b5ba2b753f200ab0cc197f3b60',
    authToken : 'e51a9d207e35e8aa70080b614beedc18'
};